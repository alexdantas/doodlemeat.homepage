Slightly edited from the `Holo Bootstrap Theme`.
Thanks a lot, BootstrapZero and Bootply.com!

* http://www.bootstrapzero.com/bootstrap-template/holo

